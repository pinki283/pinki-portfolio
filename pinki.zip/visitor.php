<?php
include("header.php");
?>
  
  <style>
    /* Center child elements */
    
.website-counter {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}
title{
padding-top: 200px;
align-items: center;
}
/* Styles for website counter container */
.website-counter {
  background-color: #ff4957;
  height: 100px;
  width: 200px;
  color: white;
  border-radius: 30px;
  font-weight: 700;
  font-size: 70px;
  margin-top: 200px;
  align-items: center;
}

/* Styles for reset button */
#reset {
  margin-top: 30px;
  background-color: #008cba;
  cursor: pointer;
  font-size: 30px;
  padding: 10px 10px;
  color: white;
  border: 0;
}

  </style>

<div class="container-fluid bg-light my-6 mt-0" id="home">
<div class="container">
            <div class="row g-5 align-items-center">
           
<h1 class="display-3 mb-3">Website visitor count:</h1>
  <div class="website-counter"></div>
  <button id="reset">Reset</button>
</div>
</div></div>


<script>
    var counterContainer = document.querySelector(".website-counter");
var resetButton = document.querySelector("#reset");
var visitCount = localStorage.getItem("page_view");

// Check if page_view entry is present
if (visitCount) {
  visitCount = Number(visitCount) + 1;
  localStorage.setItem("page_view", visitCount);
} else {
  visitCount = 1;
  localStorage.setItem("page_view", 1);
}
counterContainer.innerHTML = visitCount;

// Adding onClick event listener
resetButton.addEventListener("click", () => {
  visitCount = 1;
  localStorage.setItem("page_view", 1);
  counterContainer.innerHTML = visitCount;
});

</script>

<?php
include("footer.php");
?>