
<?php
include("header.php");
?>

    <!-- Header Start -->
    <div class="container-fluid bg-light my-6 mt-0" id="home">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 py-6 pb-0 pt-lg-0">
                    <h3 class="text-primary mb-3">I'm</h3>
                    <h1 class="display-3 mb-3">Pinki Dubey</h1>
                    <h2 class="typed-text-output d-inline"></h2>
                    <div class="typed-text d-none">Web Developer,  PHP Web Developer, Front End Developer</div>
                    <div class="d-flex align-items-center pt-5">
                        <a href="pinki.pdf" class="btn btn-primary py-3 px-4 me-5">Download CV</a>
                        <!-- <button type="button" class="btn-play" data-bs-toggle="modal" data-src="https://www.youtube.com/embed/DWRcNpR6Kdc" data-bs-target="#videoModal">
                            <span></span>
                        </button> -->
                        <!-- <h5 class="ms-4 mb-0 d-none d-sm-block">Play Video</h5> -->
                    </div>
                </div>
                <div class="col-lg-6">
                    <img class="img-fluid" src="img/pd.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

    <!-- About Start -->
    <div class="container-xxl py-6" id="about">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="d-flex align-items-center mb-5">
                        <div class="years flex-shrink-0 text-center me-4">
                            <h1 class="display-1 mb-0">9</h1>
                            <h5 class="mb-0">Month</h5>
                        </div>
                        <h3 class="lh-base mb-0">of working experience as a PHP Web developer & Designer</h3>
                    </div>
                    <p class="mb-4">Hi, I'm Pinki Dubey, a tech enthusiast with a B.Tech in Computer Science. As a PHP Web Developer at Parken Solution Pvt. Ltd., I bring creativity to coding, having worked on diverse projects from finance to healthcare. Proficient in languages like Core Java and PHP, I thrive on solving challenges. Beyond coding, I'm a music lover and a perpetual learner. Let's connect and explore the exciting intersections of technology and creativity!</p>
                    <p class="mb-3"><i class="far fa-check-circle text-primary me-3"></i>Afordable Prices</p>
                    <p class="mb-3"><i class="far fa-check-circle text-primary me-3"></i>High Quality Product</p>
                    <p class="mb-3"><i class="far fa-check-circle text-primary me-3"></i>On Time Project Delivery</p>
                    <a class="btn btn-primary py-3 px-5 mt-3" href="">Read More</a>
                    <div class="website-counter"></div>
  <!-- <button id="reset">Reset</button> -->
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="row g-3 mb-4">
                        <div class="col-sm-6">
                            <img class="img-fluid rounded" src="img/pinki (4).png" alt="">
                        </div>
                        <div class="col-sm-6">
                            <img class="img-fluid rounded" src="img/pinki (5).png" alt="">
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-3">
                        <h5 class="border-end pe-3 me-3 mb-0">Happy Clients</h5>
                        <h2 class="text-primary fw-bold mb-0" data-toggle="counter-up">10</h2>
                    </div>
                    <p class="mb-4">"Delivering satisfaction is my priority—happy clients fuel my passion. Join the satisfied ranks and experience excellence in every project."</p>
                    <div class="d-flex align-items-center mb-3">
                        <h5 class="border-end pe-3 me-3 mb-0">Projects Completed</h5>
                        <h2 class="text-primary fw-bold mb-0" data-toggle="counter-up">10</h2>
                    </div>
                    <p class="mb-0">"Successfully bringing ideas to life, I've completed diverse projects with precision and innovation. Your vision could be the next success story in my portfolio."</p>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Expertise Start -->
    <div class="container-xxl py-6 pb-5" id="skill">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h1 class="display-5 mb-5">Skills & Experience</h1>
                    <p class="mb-4">"Studied Computer Science, crafted skills; now, coding as a PHP Developer, bringing ideas to life with technology."</p>
                    <h3 class="mb-4">My Skills</h3>
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">HTML</h6>
                                    <h6 class="font-weight-bold">95%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">CSS</h6>
                                    <h6 class="font-weight-bold">90%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">PHP</h6>
                                    <h6 class="font-weight-bold">80%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">Bootstrap</h6>
                                    <h6 class="font-weight-bold">90%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-dark" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">Mysql</h6>
                                    <h6 class="font-weight-bold">80%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">Javascript</h6>
                                    <h6 class="font-weight-bold">80%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">Java</h6>
                                    <h6 class="font-weight-bold">90%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-dark" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">Wordpress</h6>
                                    <h6 class="font-weight-bold">60%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">Laravel</h6>
                                    <h6 class="font-weight-bold">50%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="skill mb-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="font-weight-bold">SDLC</h6>
                                    <h6 class="font-weight-bold">80%</h6>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <ul class="nav nav-pills rounded border border-2 border-primary mb-5">
                        <li class="nav-item w-50">
                            <button class="nav-link w-100 py-3 fs-5 active" data-bs-toggle="pill" href="#tab-1">Experience</button>
                        </li>
                        <li class="nav-item w-50">
                            <button class="nav-link w-100 py-3 fs-5" data-bs-toggle="pill" href="#tab-2">Education</button>
                        </li>
                        <!-- <li class="nav-item w-33">
                            <button class="nav-link w-100 py-3 fs-5" data-bs-toggle="pill" href="#tab-3">Training</button>
                        </li> -->
                       
                    </ul>
                    <div class="tab-content">
                        <div id="tab-1" class="tab-pane fade show p-0 active">
                            <div class="row gy-5 gx-4">
                                <div class="col-sm-6">
                                    <h5>Web Developer</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2023 - 2024</p>
                                    <h6 class="mb-0">Parken Solution Pvt. Ltd.</h6>
                                </div>
                                <div class="col-sm-6">
                                    <h5>Web Designer</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2023 - 2024</p>
                                    <h6 class="mb-0">Parken Solution Pvt. Ltd.</h6>
                                </div>
                                <div class="col-sm-6">
                                    <h5>PHP Web Developer</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2023 - 2024</p>
                                    <h6 class="mb-0">Parken Solution Pvt. Ltd.</h6>
                                </div>
                                <div class="col-sm-6">
                                    <h5>PHP Laravel Developer</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2023 - 2024</p>
                                    <h6 class="mb-0">Parken Solution Pvt. Ltd.</h6>
                                </div>
                                <div class="col-sm-6">
                                    <h5>PHP Wordpress Developer</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2021 - 2022</p>
                                    <h6 class="mb-0">Cnel India</h6>
                                </div>
                                
                            </div>
                        </div>
                        <div id="tab-2" class="tab-pane fade show p-0">
                            <div class="row gy-5 gx-4">
                                <div class="col-sm-6">
                                    <h5>BTech (Computer Science)</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2018 - 2021</p>
                                    <h6 class="mb-0">Rajasthan Technical University (RTU)</h6>
                                </div>
                                <div class="col-sm-6">
                                    <h5>High School</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2013 - 2014</p>
                                    <h6 class="mb-0">UP Board</h6>
                                </div>
                                <div class="col-sm-6">
                                    <h5>Diploma (Electronics Engg.)</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2015 - 2018</p>
                                    <h6 class="mb-0">Board of Technical Education (BTEUP)</h6>
                                </div>        
                            </div>
                        </div>
                        <div id="tab-3" class="tab-pane fade show p-0">
                            <div class="row gy-5 gx-4">
                                <div class="col-sm-6">
                                    <h5>SDET</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">Sep 2022 - Feb 2023</p>
                                    <h6 class="mb-0">QSpiders</h6>
                                </div>
                                <div class="col-sm-6">
                                    <h5>Web Development</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">May 2019 - July 2019</p>
                                    <h6 class="mb-0">Internshala</h6>
                                </div>
                                <!-- <div class="col-sm-6">
                                    <h5>Diploma (Electronics Engg.)</h5>
                                    <hr class="text-primary my-2">
                                    <p class="text-primary mb-1">2015 - 2018</p>
                                    <h6 class="mb-0">Board of Technical Education (BTEUP)</h6>
                                </div>         -->
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Expertise End -->


    <!-- Training Start -->
    <div class="container-fluid bg-light my-5 py-6" id="team">
        <div class="container">
            <div class="row g-5 mb-5 wow fadeInUp" data-wow-delay="0.1s">
                <div class="col-lg-6">
                    <h1 class="display-5 mb-0">My Training</h1>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <a class="btn btn-primary py-3 px-5" href="https://wa.me/8209322360">Hire Me</a>
                </div>
            </div>
            <div class="row g-4">
                
                <div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item d-flex flex-column flex-sm-row bg-white rounded h-100 p-4 p-lg-5">
                        <div class=" mb-3">
                            <!-- <i class="fa fa-laptop-code fa-2x text-dark"></i> -->
                            <img class="img-fluid rounded-circle border border-secondary p-2 mx-auto" src="img/training (1).png" alt="">
                        </div>
                       
                        <div class="ms-sm-4">
                            <h4 class="mb-3">Web Development</h4>
                            <!-- <h6 class="mb-3">Start from <span class="text-primary">Rs. 8000</span></h6> -->
                            <span>Platform: Internshala<br>
                                Duration: Six weeks (2020)<br>
                                Modules: HTML & CSS, Bootstrap, SQL, PHP.</span>
                            
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item d-flex flex-column flex-sm-row bg-white rounded h-100 p-4 p-lg-5">
                        <div class="mb-3">
                            <!-- <i class="fa fa-code fa-2x text-dark"></i> -->
                            <img class="img-fluid rounded-circle border border-secondary p-2 mx-auto" src="img/training (2).png" alt="">
                        </div>
                       <div class="ms-sm-4">
                            <h4 class="mb-3">SDET Course</h4>
                            <!-- <h6 class="mb-3">Start from <span class="text-primary">Rs. 8000</span></h6> -->
                            <span>Institute: QSpiders BTM, Bengaluru <br> Duration: Six Month (Sep 2022-Feb 2023)<br>Modules: Core Java, SQL, Manual Testing, Selenium.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Training End -->


    <!-- Projects Start -->
    <div class="container-xxl py-6 pt-5" id="project">
        <div class="container">
            <div class="row g-5 mb-5 align-items-center wow fadeInUp" data-wow-delay="0.1s">
                <div class="col-lg-6">
                    <h1 class="display-5 mb-0">My Projects</h1>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <a class="btn btn-primary py-3 px-5" href="https://wa.me/8209322360">Hire Me</a>
                </div>
            </div>
            <div class="row g-4 portfolio-container wow fadeInUp" data-wow-delay="0.1s">
                <div class="col-lg-4 col-md-6 portfolio-item first">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (1).png" alt="">
                        <div class="portfolio-btn">
                            <a href="http://rajroxproduction.com/" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item second">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (2).png" alt="">
                        <div class="portfolio-btn">
                            <a href="https://voyagerindiaproduction.com" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item first">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (3).png" alt="">
                        <div class="portfolio-btn">
                            <a href="http://dermamagnetica.in/" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item second">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (5).png" alt="">
                        <div class="portfolio-btn">
                            <a href="http://mahasagarseeds.com/" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>
              
                <div class="col-lg-4 col-md-6 portfolio-item second">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (4).png" alt="">
                        <div class="portfolio-btn">
                            <a href="http://ananddentalclinics.com/" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item second">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (8).png" alt="">
                        <div class="portfolio-btn">
                            <a href="http://baralainvestment.com/" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item second">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (6).png" alt="">
                        <div class="portfolio-btn">
                            <a href="http://omofsil.com/" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item second">
                    <div class="portfolio-img rounded overflow-hidden">
                        <img class="img-fluid" src="img/web_logo (7).png" alt="">
                        <div class="portfolio-btn">
                            <a href="http://parkensolution.com/yuwan/" class="btn btn-lg btn-outline-secondary border-2 mx-1">Visit Website</a>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
    <!-- Projects End -->

 
    <!-- Service Start -->
    <div class="container-xxl py-6 pb-5" id="service">
        <div class="container">
            <div class="row g-5 mb-5 wow fadeInUp" data-wow-delay="0.1s">
                <div class="col-lg-6">
                    <h1 class="display-5 mb-0">My Services</h1>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <a class="btn btn-primary py-3 px-5" href="https://wa.me/8209322360">Hire Me</a>
                </div>
            </div>
            <div class="row g-4">
               
             
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item d-flex flex-column flex-sm-row bg-white rounded h-100 p-4 p-lg-5">
                        <div class="bg-icon flex-shrink-0 mb-3">
                            <i class="fa fa-laptop-code fa-2x text-dark"></i>
                        </div>
                       
                        <div class="ms-sm-4">
                            <h4 class="mb-3">Web Development</h4>
                            <!-- <h6 class="mb-3">Start from <span class="text-primary">Rs. 8000</span></h6> -->
                            <span>Web development services involve creating and designing websites and web-based software solutions.</span>
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item d-flex flex-column flex-sm-row bg-white rounded h-100 p-4 p-lg-5">
                        <div class="bg-icon flex-shrink-0 mb-3">
                            <i class="fa fa-code fa-2x text-dark"></i>
                        </div>
                       <div class="ms-sm-4">
                            <h4 class="mb-3">Web Design</h4>
                            <!-- <h6 class="mb-3">Start from <span class="text-primary">Rs. 8000</span></h6> -->
                            <span>Web design services involve creating and designing websites that are visually appealing and user-friendly.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--  -->
        
    </div>
    <!-- Service End -->


    <!-- Testimonial Start -->
    <div class="container-fluid bg-light py-5 my-5" id="testimonial">
        <div class="container-fluid py-5">
            <h1 class="display-5 text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Testimonial</h1>
            <div class="row justify-content-center">
                <div class="col-lg-2 d-none d-lg-block">
                   
                </div>
                <div class="col-lg-8 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="owl-carousel testimonial-carousel">
                        <div class="testimonial-item text-center">
                            <div class="position-relative mb-5">
                               
                                <div class="testimonial-icon">
                                    <i class="fa fa-quote-left text-primary"></i>
                                </div>
                            </div>
                            <p class="fs-5 fst-italic">  Thank you Pinki Ji,
                                Your hard work was very good, my distributors also liked the website prepared by you.</p>
                            <hr class="w-25 mx-auto">
                            <h5>RK Jangid</h5>
                            <span>Sales & Marketing Director</span>
                        </div>
                        
                      
                    </div>
                </div>
                <div class="col-lg-2 d-none d-lg-block">
                    <div class="testimonial-right h-100">
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->




    <!-- Contact Start -->
    <div class="container-xxl pb-5" id="contact">
        <div class="container py-5">
            <div class="row g-5 mb-5 wow fadeInUp" data-wow-delay="0.1s">
                <div class="col-lg-6">
                    <h1 class="display-5 mb-0">Contact Me</h1>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <a class="btn btn-primary py-3 px-5" href="">Say Hello</a>
                </div>
            </div>
            <div class="row g-5">
                <div class="col-lg-5 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <p class="mb-2">My Address:</p>
                    <h3 class="fw-bold">Shanthi Nagar, Gurjar Ki Thadi, Jaipur, Rajasthan 302019</h3>
                    <hr class="w-100">
                    <p class="mb-2">Call me:</p>
                    <h3 class="fw-bold">+91 8209322360</h3>
                    <hr class="w-100">
                    <p class="mb-2">Mail me:</p>
                    <h3 class="fw-bold">dubeypinki099@gmail.com</h3>
                    <hr class="w-100">
                    <p class="mb-2">Follow me:</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-square btn-primary me-2" href="https://wa.me/8209322360"><i class="fab fa-whatsapp"></i></a>
                        <a class="btn btn-square btn-primary me-2" href="https://www.facebook.com/profile.php?id=100076651717698"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-square btn-primary me-2" href="https://www.instagram.com/pinkidubey73/"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-square btn-primary me-2" href="https://www.linkedin.com/in/pinki-dubey-239a771b0"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-7 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <p class="mb-4">Reach out for a new project or just say hello!</p>
                    <form action="Email.php" method="post">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Your Name">
                                    <label for="name">Your Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Your Email">
                                    <label for="email">Your Email</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" id="phone" name="phone" placeholder="Your Number">
                                    <label for="subject">Subject</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Leave a message here" id="message" name="message" style="height: 100px"></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary py-3 px-5" name="submit" type="submit">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->


   <?php
   include("footer.php");
   ?>