<?php
if (!empty($_POST))
{
	
	$form_name = $_POST['name'];
	$form_phone = $_POST['phone']; 
	$form_email = $_POST['email']; 	
	$form_message = $_POST['message'];

	$success = true;
    //    echo $form_name; echo $form_email;echo $form_phone; echo $form_message;
	
	if($success)
	{
		sendMail($form_name,$form_phone, $form_email,$form_message);
	}
}
function sendMail($form_name, $form_phone, $form_email, $form_message)
{
	
	
	$message='Dear Pinki,You Have Received An Enquiry From .:'.$form_name.' Details Of Visitor Are Below: Enquiry Details
Name:'.$form_name.'
Phone:'.$form_phone.'
Email:'.$form_email.'
Message:'.$form_message.'';
	
	
	$headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

   mail("dubeypinki099@gmail.com","Enquiry from website",$message);
    
   ?>
<script>window.location="index.html" </script>
<?php

}
?>
